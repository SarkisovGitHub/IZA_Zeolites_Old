#!/bin/bash --login

for d in */ ; do
    echo "$d" >> poreblazer_results.dat
    cd $d/pb_0.1/
    cat results | grep 'System volume in A^3:' >> ../../poreblazer_results.dat
    cat results | grep 'System mass, g/mol:' >> ../../poreblazer_results.dat
    cat results | grep 'System density, g/cm^3:' >> ../../poreblazer_results.dat

    cat results | grep 'Pore limiting diameter in A:' >> ../../poreblazer_results.dat
    cat results | grep 'Maximum pore diameter in A:' >> ../../poreblazer_results.dat
    cat results | grep 'The system is percolated in' >> ../../poreblazer_results.dat

    cat results | grep 'Total surface area in A^2:' >> ../../poreblazer_results.dat
    cat results | grep 'Total surface area per volume in m^2/cm^3:' >> ../../poreblazer_results.dat
    cat results | grep 'Total surface area per mass in m^2/g:' >> ../../poreblazer_results.dat

    cat results | grep 'Total helium volume in A^3:' >> ../../poreblazer_results.dat
    cat results | grep 'Total helium volume in cm^3/g:' >> ../../poreblazer_results.dat

    cat results | grep 'Total geometric volume in A^3:' >> ../../poreblazer_results.dat
    cat results | grep 'Total geometric volume in cm^3/g:' >> ../../poreblazer_results.dat

    cat results | grep 'Total probe-occupiable volume in A^3:' >> ../../poreblazer_results.dat
    cat results | grep 'Total probe-occupiable volume in cm^3/g:' >> ../../poreblazer_results.dat
    cat results | grep 'Total fraction of free volume:' >> ../../poreblazer_results.dat

    cat results | grep 'Network-accessible surface area in A^2:' >> ../../poreblazer_results.dat
    cat results | grep 'Network-accessible surface area per volume in m^2/cm^3:' >> ../../poreblazer_results.dat
    cat results | grep 'Network-accessible surface area per mass in m^2/g:' >> ../../poreblazer_results.dat

    cat results | grep 'Network-accessible helium volume in A^3:' >> ../../poreblazer_results.dat
    cat results | grep 'Network-accessible helium volume in cm^3/g:' >> ../../poreblazer_results.dat

    cat results | grep 'Network-accessible geometric volume in A^3:' >> ../../poreblazer_results.dat
    cat results | grep 'Network-accessible geometric volume in cm^3/g:' >> ../../poreblazer_results.dat

    cat results | grep 'Network-accessible probe-occupiable volume in A^3:' >> ../../poreblazer_results.dat
    cat results | grep 'Network-accessible probe-occupiable volume in cm^3/g:' >> ../../poreblazer_results.dat
    cat results | grep 'Network-accessible fraction of free volume:' >> ../../poreblazer_results.dat
    cd ../../
done


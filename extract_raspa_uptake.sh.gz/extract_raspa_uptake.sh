#!/bin/bash --login

for d in */ ; do
    echo "$d" >> argon_uptake_raspa.dat
    cd $d/raspa/Output/System_0/
    cat output_zeolite_* | grep -B 9 'Average Widom Rosenbluth factor' >> interim_result.dat
    cat interim_result.dat | grep 'mol/kg framework' >> ../../../../argon_uptake_raspa.dat
    rm interim_result.dat
    cd ../../../../
done


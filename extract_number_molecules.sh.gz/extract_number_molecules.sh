#!/bin/bash --login

for d in */ ; do
    # print name of the material
    echo "$d" >> number_of_argon_raspa.dat
    
    # cd to raspa directory
    cd $d/raspa/
    
    # extract the number of unit cell in the material
    cat simulation.input | grep 'UnitCells' >> ../../number_of_argon_raspa.dat
    
    # cd to Output directory of raspa
    cd Output/System_0/

    # extract the number of adsorbed molecules
    cat output_zeolite_* | grep -A 11 'Number of molecules:' >> interim_results.dat
    cat interim_results.dat | grep 'Average' >> ../../../../number_of_argon_raspa.dat
    rm interim_results.dat

    # cd to the root directory
    cd ../../../../
done


#!/bin/bash --login

for d in */ ; do
    echo "$d" >> removed_zeolites.dat
    cd $d/raspa/Output/System_0/
    rm wrong_output.dat
    cd ../../../../
done

